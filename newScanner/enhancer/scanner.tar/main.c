
//Copyright (c) in silico Labs, LLC 2009

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int mainAux(int, char* argv[] );

int main (int argc, char* argv[]) {
 
   mainAux(argc, argv);
  
}

