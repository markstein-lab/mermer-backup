//Copyright (c) in silico Labs, LLC 2008, 2009, 2015

#include <stdlib.h>
#include <stdio.h>
#include "timer.h"
#include "scanner.h"
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/fcntl.h>

int getpagesize();
int numberOfChromosomes;
char *chrName[100];
int readContigs(FILE *);
void readgenenames(FILE *, int);

void readGenome() {
   FILE* qnames;
   FILE* master;
   FILE* mrnastuff;
   int i, j, k, m;
   unsigned char c;
   unsigned char *DNAs;
   /*unsigned*/ char line[5000];
   /*unsigned*/ char temp[500];
   int pagesize;
   int filedes;
   struct stat sbuf;
   char genomeName[100];
 
#if (scanWidth < 5)
   unsigned char word;
#else
   unsigned short int word;
#endif
   char message[100];
   
// This first section reads in the genome itself  
//   qnames = fopen(fullName(pathName, "genome.txt"), "rb");
//   printf("File name is %s\n", fullName(pathName, "genome.txt"));
   if (utr3 | utr5 | orf | cds) strcpy(genomeName, "xmrnadata.txt");
   else strcpy(genomeName, "genome.txt");
   filedes = open(fullName(pathName, genomeName), O_RDONLY);
   pagesize = getpagesize();
   if (filedes == -1) {
      printf("Genome does not exist -- quitting\n");
      exit(0);
   }
   stat(fullName(pathName, genomeName), &sbuf);
   DNAstring = mmap(/*(caddr_t)*/0, sbuf.st_size + pagesize, PROT_READ, MAP_SHARED, filedes, 0);
   if (DNAstring == (unsigned char*) -1){
      both("File mapping did not work!\n");
      exit(1);
   }
   goto genomeHasBeenRead;

#if (scanWidth == 1 || scanWidth == 2 || scanWidth == 4 )
   DNAs = (unsigned char *)DNAstring;
   for (i = 0; i < (DNALen/4 + 8); i++) {
      DNAs[i] = fgetc(qnames);
      if(feof(qnames)) break;
   }
   
   counter = i;
#ifdef DEBUG
   sprintf(message, "compact genome took %u bytes (%u nucleotides)\n",
      counter, DNALen);
   both(message);
#endif
   fclose(qnames);
#else
   j = 0;
   k = 0;
   word = 0;
   for (i = 0; i < (DNALen/4 + 8); i++) {
      c = fgetc(qnames);
      if (j + 8 <= 2*scanWidth) {
         word = (word << 8) + c;
         j = j + 8; 
         if (j == 2*scanWidth) {
            DNAstring[k++] = word;
            j = 0;
            word = 0;
         }
      }
      else if (j + 8 > 2*scanWidth) {
         word <<= 2*scanWidth - j;
         word += (c>>(8 - 2*scanWidth + j));
         DNAstring[k++] = word;
         j = 8 - 2*scanWidth + j;
         word = c & ((1<<j) - 1);
         if (j == 2*scanWidth) {
            DNAstring[k++] = word;
            word = 0;
            j = 0;
         }
      }         
   }
   counter = k;
#ifdef DEBUG
   sprintf(message, "i = %d, k = %d, size of word = %d\n", i, k, sizeof(word));
   both (message);
   sprintf(message, "compact genome took %d bytes (%d nucleotide)\n",
      counter*sizeof(word), DNALen);
   both (message);
#endif
   fclose (qnames);
#endif

//The genome has now been read in.
//Next, we read in supporting data, that describes the chromosomes and
//tells where the genes are on the chromosomes

genomeHasBeenRead:
   master = fopen(fullName(pathName, "master.txt"), "r");
   numberOfChromosomes = 0;
   while(1) {
      line[0] = 0;                  //initialize line to empty string
      fscanf(master, "%s", line);   //read in a chromosome name
      if (strlen(line)) {           //test if a name was found
         chrName[numberOfChromosomes] = malloc(strlen(line) + 1);
         strcpy(chrName[numberOfChromosomes], line); //save chr. name
         numberOfChromosomes++;     //increase number of Chromosomes
      }
      else {
         fclose(master);
         break;
      }
   }

   indexFile = fopen(fullName(pathName, "xchrdata.txt"), "r");
   map = malloc(mapSize * sizeof(ann_index));
   if (mrnaCount) {
      mrnaInfo = malloc(mrnaCount * sizeof(mrnaID));
      mrnastuff = fopen(fullName(pathName, "xmrnastart.txt"), "r");
      if (mrnastuff == 0) {
         printf("mRNA info file not found\n");
         exit(0);
      }
      for (i = 0; i < mrnaCount; i++) {
         if (feof(mrnastuff)) {
            printf("Premature end of mrnastart file\n");
            exit(0);
         }
         getLine(line, mrnastuff); 
         sscanf(line, "%u %u", &mrnaInfo[i].geneID, &mrnaInfo[i].mrnaStart);
      }
      
   }
   if (map == NULL) {
      both("insufficient space for mapping tables\n");
      exit (0);
   }
   if(indexFile == NULL) {
      printf("Annotation index file not found\n");
      exit(0);  //abort the run 
   }
   else {  //read in the chromosome data
      for (i = 0; i < mapSize; i++) {
         if (feof(indexFile)) {
            printf("premature end of gene info file!\n");
            exit (0);
         }
         for (j = 0; j < 10; j++) line[j] = 0;
         getLine(line, indexFile);
         //now read in about the gene: contig number that contains it, 
         //start and stop of gene, direction,
         //information about the various mRNAs and the exons
         //and finally the gene name
         j = sscanf(line, "%d%d%d %c %d%d %498[^\n\r]",
                    &map[i].annot_number, &map[i].start,
                    &map[i].stop, &map[i].direction, &map[i].numberOfmRNAs,
                    &map[i].numberOfExons, temp);
         map[i].geneName = malloc(strlen(temp) + 1);
         strcpy(map[i].geneName, temp);
         map[i].touched = 0;  //have not yet found anything near this gene

         //now allocate space to hold the alternate splicing info for this gene
         map[i].mrnaInfo = malloc(sizeof(int) *
                           (map[i].numberOfmRNAs)*(2*map[i].numberOfExons + 4));

         for (j = 0; j < map[i].numberOfmRNAs; j++) {
            m = j * (2*map[i].numberOfExons + 4);  //Where jth row begins
            //Read in the RNA type and number of exons;
            fscanf(indexFile, "%d%d", 
                   &map[i].mrnaInfo[m], &map[i].mrnaInfo[m+1]); 
            for (k = 0; k < map[i].mrnaInfo[m+1] + 1; k++) {
               fscanf(indexFile, "%d%d", &map[i].mrnaInfo[m+2+2*k],
                                    &map[i].mrnaInfo[m+3+2*k]);
            }
            fscanf(indexFile, "\n");
         }
      }
   }
   if (i != mapSize) both("chrdata file did not have right number of records.\n");
   fclose(indexFile);

//next, we read in the info about chromosome arms and contigs
   arm = malloc((ncontigs+2) * sizeof(int*));
   if (arm == NULL) {
      both("Insufficient space for chromosome table\n");
      exit (0);
   }

   annotName = malloc ((ncontigs+2)* sizeof(char*));
   if (annotName == NULL) {
      both("Insufficient space for contigs table\n");
      exit(0);
   }

   chromoName = malloc ((ncontigs+2)* sizeof(char*));
   if (chromoName == NULL) {
      both ("Insufficient space for Chromosome Name Table\n");
      exit (0);
   }

   extable = malloc ((extableSize + 1) * 2 * sizeof (int));
   if (extable == NULL) {
      both("Not enough space for exception table\n");
      exit(0);
   } 

   if (map == 0) {
      //No space available!
      printf("Not enough space for the gene map!\n");
      exit(0);
   }
   
  
   qnames = fopen(fullName(pathName, "xcontigs.txt"), "r");
   k = 0;
   k = readContigs(qnames); 
   if (k != ncontigs) {
      printf(message,
            "wrong number of contings, wanted %d, found %d\n", ncontigs, k);
      both(message);
   }
   fclose(qnames);

   arm[k] = DNALen;                //end of genome
   arm[k+1] = 0;
   chromoName[k] = malloc(20);
   strcpy(chromoName[k], "end_of_genome");
   chromoName[k+1] = chromoName[k];
   annotName[k] = chromoName[k];
   annotName[k+1] = annotName[k];
   qnames = fopen(fullName(pathName, "exceptions.txt"), "r");
   for (i = 0; i < extableSize; i++) {
      getLine(line, qnames);
      sscanf(line, "%d %8x", &extable[2*i], &extable[2*i+1]);
      if (feof(qnames)) {
         printf("Exception table too short\n");
         exit(0);
      }
   }
   extable[2*i] = (DNALen/32) + 1;    //dummy last entry beyond the genome
   extable[2*i + 1] = 0xFFFFFFFF;
   fclose (qnames);


   allnames = fopen(fullName(pathName, "xallnames.txt"), "r");

   if (allnames == NULL) {
      synCount = 0;
      printf("File of gene-names is missing\n");
      exit(1);
   }
   geneNumber = malloc(synCount * sizeof(int));
   geneName = malloc(synCount * sizeof(char*));
   if (synCount > 0 && (geneNumber == NULL || geneName == NULL)) {
     both ("Insufficient space for gene synonym name table\n");
     exit (0);
   }


   if(synCount) readgenenames(allnames, synCount);

}
